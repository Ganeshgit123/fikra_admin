// export layout related constants
export const LAYOUT_VERTICAL = 'vertical';